# AVR Speech Recognition Fingerprint Lock System

This project implements a fingerprint-based lock system using an AVR microcontroller (specifically ATmega series) and a UART interface for communication. It involves collecting and classifying fingerprint data to either lock or unlock a mechanism based on the detected fingerprint match.

## Components Used

- **Microcontroller:** AVR ATmega series (e.g., ATmega32)
- **Peripherals:**
  - Microphone for fingerprint input
  - Button for initiating data collection
  - LEDs for indicating lock/unlock status
- **Software Tools:**
  - AVR-GCC for compiling
  - AVRDUDE for programming
  - Terminal software (e.g., CoolTerm) for UART communication
	
## Setup and Configuration

1. **Hardware Setup:**
   - Connect the microphone to analog input pin (e.g., A0).
   - Connect the button to a digital input pin (e.g., PD7).
   - Connect LEDs to digital output pins (e.g., PD6 for lock, PC0 for unlock).

2. **Software Configuration:**
   - Modify `F_CPU` in the code to match the clock frequency of your AVR chip.
   - Ensure proper setup of UART baud rate (`USART_BAUDRATE`) and pin configurations.

## How to Use

1. **Compilation:**
   - Compile the code using AVR-GCC.
   - Example command:
     ```bash
     avr-gcc -mmcu=atmega32 -o main.elf main.c
     ```

2. **Programming:**
   - Use AVRDUDE to flash the compiled binary onto the AVR chip.
   - Example command:
     ```bash
     avrdude -p atmega32 -c <programmer> -P <port> -U flash:w:main.elf
     ```

3. **Operation:**
   - After programming, power up the AVR board.
   - Press the button to start fingerprint data collection.
   - Follow UART messages to understand the status of fingerprint detection.

## Additional Notes

- **UART Communication:**
  - Connect the AVR board to a PC via UART for real-time communication.
  - Use a terminal software (e.g., CoolTerm) with the configured baud rate to monitor messages.
  
- **Fingerprint Classification:**
  - The system uses Euclidean distance for fingerprint classification.
  - Adjust fingerprint data arrays (`lock_Finger_Print` and `unlock_Finger_Print`) for different fingerprint templates.

## License
This project is created and maintained by Abdelrahman Elsayed and is licensed under the MIT License.

##How It Works

Watch the attached video.

