#define F_CPU					(11052900UL)	// Define the frequancy

/********************************************Libraries*********************************************/
#include <math.h>
#include <avr/io.h>
#include <util/delay.h>
#include <string.h>
#include <ctype.h>

/***********************************************Macros*********************************************/
#define SET_BIT(REG,BIT) 		(REG |= (1<<BIT))
#define CLEAR_BIT(REG,BIT) 		(REG &= (~(1<<BIT)))
#define BIT_IS_SET(REG,BIT) 	(REG & (1 << BIT))
#define BIT_IS_CLEAR(REG,BIT) 	(!(REG & (1 << BIT)))

#define ZERO				(0)

#define ARRAY_SIZE			(200)
#define LOCK_NUM			(4)
#define MAX_DISTANCE        (INT32_MAX)

#define MICROPHONE_PIN		(0)
#define BUTTON_PIN			(7)
#define LOCK_PIN			(6)
#define UNLOCK_PIN			(0)
#define USART_BAUDRATE		(9600)

/*******************************************Data Types********************************************/
typedef unsigned char 	uint8;
typedef signed char		sint8;
typedef unsigned short 	uint16;
typedef signed short 	sint16;
typedef unsigned long 	uint32;
typedef signed long 	sint32;

/*************************************Data For Classification***********************************/

uint8 lock_Finger_Print[LOCK_NUM][ARRAY_SIZE] = {
	{69,75,76,81,36,68,61,65,75,82,19,117,37,137,137,138,137,137,67,18,18,137,18,18,137,19,138,138,138,137,139,17,138,138,18,18,137,18,14,138,137,137,137,138,138,138,122,122,98,73,78,66,65,80,67,65,69,66,69,71,69,71,73,69,73,73,73,70,74,70,75,76,74,75,54,72,69,53,62,75,35,93,91,42,127,135,138,16,56,53,87,100,95,87,72,63,71,80,79,64,59,68,77,80,78,74,72,74,73,72,73,74,73,72,71,72,75,73,74,72,73,73,75,75,74,73,73,73,73,73,73,74,74,74,73,73,73,73,74,72,74,73,72,73,74,72,72,73,74,73,75,73,73,72,73,75,74,72,75,74,72,72,73,72,73,72,73,74,73,74,73,74,74,74,71,73,72,73,74,73,75,73,84,70,73,74,74,72,74,71,71,73,73,71,73,75,75,72,71,73},
	{117,75,77,78,75,137,89,52,17,17,138,137,138,17,18,137,137,19,137,137,19,16,137,19,18,137,139,138,19,18,137,18,16,138,97,137,137,138,30,76,71,15,16,16,14,34,54,42,57,54,59,68,60,53,61,67,68,75,70,74,73,72,75,79,74,69,70,75,75,137,17,137,16,18,18,17,138,138,137,137,137,137,137,137,18,18,17,51,121,137,137,138,137,137,137,137,137,137,126,100,88,82,77,74,73,71,68,74,71,70,70,74,73,74,73,71,70,72,73,74,72,72,74,73,73,74,73,74,74,75,74,72,72,72,72,76,76,72,69,69,75,75,75,73,71,74,72,72,73,73,73,71,74,74,72,72,71,75,73,71,72,74,72,75,73,74,72,72,73,74,76,74,73,73,74,69,72,75,74,71,69,66,75,73,71,71,75,76,74,69,70,76,78,74,69,71,77,78,71,67},
	{73,69,76,89,111,33,81,81,60,77,16,18,100,137,137,138,86,27,17,18,137,14,17,18,19,16,137,140,19,15,138,140,18,20,19,18,138,20,20,138,18,137,75,16,16,16,28,22,15,21,52,59,62,43,45,60,71,65,66,62,66,66,67,66,71,69,75,74,76,72,71,73,75,76,72,81,16,138,18,18,137,15,137,17,138,138,80,138,16,106,138,55,31,41,47,66,16,77,74,75,75,75,72,73,73,76,73,73,71,83,73,70,74,73,72,72,74,71,71,76,74,75,72,74,75,73,75,74,76,77,71,73,74,73,73,72,74,74,72,74,73,72,74,72,77,74,74,72,73,73,74,70,72,74,70,75,72,74,74,74,76,72,73,68,73,75,76,72,74,72,72,70,72,73,70,76,74,73,71,79,75,71,68,75,70,73,73,72,73,73,77,74,71,75,70,76,76,77,71,74},
	{16,18,137,112,138,137,137,19,136,138,137,20,17,138,19,81,139,19,137,139,20,18,138,20,18,138,20,18,15,138,138,47,39,100,59,30,34,73,30,43,43,42,58,55,56,64,58,62,65,60,66,71,74,69,69,68,68,74,79,78,75,74,72,74,73,72,76,74,70,69,81,16,18,16,16,137,138,137,137,16,57,137,137,138,138,41,137,137,138,137,138,137,138,138,138,138,138,138,138,100,93,80,74,71,70,68,70,63,66,67,67,71,73,74,72,69,70,72,73,72,73,74,73,74,74,73,73,73,73,74,74,73,73,73,72,75,74,75,72,72,75,71,72,73,74,74,72,72,73,73,85,77,72,74,73,73,73,73,74,72,71,74,73,71,74,75,74,73,72,74,73,71,73,75,74,72,73,75,76,72,74,75,71,70,73,75,74,73,72,75,74,73,73,74,73,72,73,74,72,72},
};

uint8 unlock_Finger_Print[LOCK_NUM][ARRAY_SIZE] = {
	{137,137,137,17,138,17,138,17,17,137,18,137,138,137,137,33,29,137,13,17,137,15,18,137,45,17,137,15,48,137,23,137,137,92,137,137,79,137,137,126,137,137,137,137,137,17,16,137,138,18,16,138,17,15,138,137,137,137,15,88,36,137,138,138,137,138,106,91,94,81,79,81,70,67,73,62,70,72,70,69,73,72,73,76,74,74,76,70,74,71,73,71,73,86,85,71,73,58,80,71,72,75,71,72,75,73,73,73,75,72,71,73,71,73,74,74,75,73,75,73,76,70,74,72,76,71,75,71,77,70,76,71,74,71,75,74,72,72,73,75,72,75,72,75,70,74,71,74,70,73,73,74,73,73,73,74,73,72,73,74,72,70,73,73,71,70,75,73,72,71,74,73,73,72,77,71,76,72,73,70,77,72,72,72,75,75,73,73,72,72,72,76,72,74,71,78,71,71,73,74},
	{26,59,18,137,138,137,138,18,137,138,137,15,137,137,15,18,137,138,85,137,137,138,137,137,138,137,138,138,102,137,137,90,137,138,80,138,138,99,138,138,15,80,137,45,16,138,138,138,137,137,137,74,138,138,137,137,18,137,137,15,138,138,138,137,137,138,137,137,127,121,93,79,75,80,77,72,75,66,75,72,71,75,75,69,72,73,74,71,71,70,70,69,73,77,85,71,57,66,89,78,77,75,69,73,72,77,73,73,74,73,71,72,73,72,71,71,76,74,75,75,76,75,74,74,74,70,70,73,73,73,71,74,73,74,73,74,73,73,73,74,73,73,74,74,73,72,74,72,73,71,72,72,74,74,74,72,72,72,75,75,72,71,75,72,74,73,75,74,71,73,71,73,71,75,73,72,73,73,74,74,73,72,74,74,73,75,71,71,73,71,73,72,73,74,76,72,73,72,71,71},
	{137,18,137,137,137,137,137,137,17,18,137,138,53,137,28,137,137,137,137,85,137,137,15,137,137,15,137,137,54,137,137,30,137,138,136,137,137,137,137,43,137,137,18,137,17,18,137,138,19,137,137,137,137,137,137,137,137,137,137,137,23,137,137,137,137,127,116,95,88,54,78,88,67,73,78,72,74,75,71,73,74,72,73,71,74,71,72,72,71,73,87,84,82,76,55,65,88,73,74,74,71,70,66,70,61,80,90,84,69,66,65,65,74,87,84,73,70,71,73,69,73,72,69,73,71,71,75,72,76,72,77,71,71,77,74,69,72,75,72,77,70,77,74,78,75,74,71,71,75,67,75,73,76,70,74,74,75,70,72,73,70,73,74,74,76,73,73,72,76,75,72,71,71,73,73,72,74,74,72,75,74,74,72,76,65,74,70,78,73,79,71,71,77,72,78,69,78,73,79,69},
	{137,137,33,18,137,18,17,137,137,78,138,136,137,16,15,137,137,137,137,137,137,137,137,137,137,136,137,137,78,137,137,111,137,137,82,137,137,15,137,137,15,135,137,94,137,137,14,137,137,18,137,137,17,137,137,17,137,137,86,137,137,137,137,137,127,103,104,92,86,87,71,76,76,70,69,70,66,67,73,72,71,73,73,70,75,71,70,73,73,71,71,74,63,52,67,93,66,74,70,70,76,70,74,72,74,74,75,74,71,72,75,72,71,73,73,73,73,74,73,73,73,73,70,72,77,75,73,72,72,73,73,73,74,73,73,73,73,71,73,73,72,73,72,73,72,74,74,73,73,74,74,73,72,73,72,74,74,72,74,73,73,72,75,74,74,73,72,73,73,70,72,73,72,72,73,73,73,73,73,70,73,74,73,74,75,71,72,74,73,73,72,73,75,74,74,73,73,76,72,75},
};

/*****************************************Enums**************************************/
typedef enum {
	LOCK,
	UNLOCK,
	UNKNOWN
} Classification;

/**************************************Functions***********************************/

//ADC initialization
void ADC_Init() {
	SET_BIT(ADCSRA, ADEN);					//ADC enable
	SET_BIT(ADCSRA, ADPS0);					//Prescalar CLK (128)
	SET_BIT(ADCSRA, ADPS1);				
	SET_BIT(ADCSRA, ADPS2);
	
	SET_BIT(ADMUX, REFS0);					//AVCC (5V) for ref.
}

//ADC read input
uint32 ADC_Read(uint8 channel) {
	channel = channel & 0b00000111;
	ADMUX = (ADMUX & 0xF8) | channel;
	
	SET_BIT(ADCSRA, ADSC);					//Initiate the conversion
	while (BIT_IS_SET(ADCSRA, ADSC));		//Check if the conversion is done

	return (uint32)(ADCL | (ADCH << 8));	//Return the output
}

//UART initialization
void UART_init() {
	uint8 baud = ((F_CPU / 8) / USART_BAUDRATE) - 1; //Set the baud rate
	
	SET_BIT(UCSRA, U2X);							//Enable double speed
	
	SET_BIT(UCSRB, RXEN);							//Enable receive
	SET_BIT(UCSRB, TXEN);							//Enable transmit
	
	UCSRC |= (1 << URSEL) | (1 << UCSZ0) | (1 << UCSZ1);	//8 bit data 
	
	UBRRL = baud;							
	UBRRH = (baud >> 8);
}

//Transmit Char
void UART_TxChar(uint8 c) {
	while (!(UCSRA & (1 << UDRE))); //Check if the buffer is empty
	UDR = c;
}

//Transmit String
void UART_sendString(uint8* str) {
	uint8 counter = ZERO;
	
	for (counter = ZERO; counter < strlen(str); counter++) {
		UART_TxChar(str[counter]);
	}
}

//Transmit Integer
void UART_sendInt(uint32 num) {
	uint8 str[11];
	uint8 i = 0;

	if (num == 0) {
		UART_TxChar('0');
		return;
	}

	while (num > 0) {
		str[i++] = '0' + (num % 10);
		num /= 10;
	}

	while (i > 0) {
		UART_TxChar(str[--i]);
	}
}

/************************************For Classification******************************/
uint32 euclideanDistance(uint8 *array1, uint8 *array2, uint8 size) {
	uint32 distance = 0;
	for (uint16 i = 0; i < size; i++) {
		distance += pow(array1[i] - array2[i], 2);
	}
	return distance;
}

Classification classifyFingerprint(uint8 *buffer) {
	uint32 totalLockDistance = 0;
	uint32 totalUnlockDistance = 0;
	uint32 lockDistances[LOCK_NUM];
	uint32 unlockDistances[LOCK_NUM];

	for (uint16 i = 0; i < LOCK_NUM; i++) {
		lockDistances[i] = euclideanDistance(buffer, lock_Finger_Print[i], ARRAY_SIZE);
		unlockDistances[i] = euclideanDistance(buffer, unlock_Finger_Print[i], ARRAY_SIZE);

		UART_sendString("Distance to Lock ");
		UART_sendInt(i);
		UART_sendString(": ");
		UART_sendInt(lockDistances[i]);
		UART_sendString("\n");

		UART_sendString("Distance to Unlock ");
		UART_sendInt(i);
		UART_sendString(": ");
		UART_sendInt(unlockDistances[i]);
		UART_sendString("\n");

		totalLockDistance += lockDistances[i];
		totalUnlockDistance += unlockDistances[i];
	}

	uint32 averageLockDistance = totalLockDistance / LOCK_NUM;
	uint32 averageUnlockDistance = totalUnlockDistance / LOCK_NUM;

	if (averageLockDistance < averageUnlockDistance) {
		return LOCK;
		} else {
		return UNLOCK;
	}
}

//Map 16 bit value to 8 bit
uint8 map16to8(uint16 x) {
	uint16 x_min = 0;
	uint16 x_max = 1024;
	uint8 y_min = 0;
	uint8 y_max = 255;

	return (uint8)(((uint32)(x - x_min) * (y_max - y_min)) / (x_max - x_min));
}

//Project initialization
void project_Init() {
	CLEAR_BIT(DDRA, MICROPHONE_PIN);	//Set pin A0 to input
	CLEAR_BIT(DDRD, BUTTON_PIN);
	SET_BIT(PORTD, BUTTON_PIN);
	SET_BIT(DDRD, LOCK_PIN);
	SET_BIT(DDRC, UNLOCK_PIN);
	
	ADC_Init();
	UART_init();
}

int main() {
	project_Init();

	uint16 value = ZERO;
	uint8 buffer[ARRAY_SIZE];
	uint16 counter = ZERO;
	uint8 buttonPressed = 0;

	while (1) {
		// Check if the button is pressed (active low)
		if (BIT_IS_CLEAR(PIND, BUTTON_PIN) && !buttonPressed) {
			CLEAR_BIT(PORTD, LOCK_PIN);
			CLEAR_BIT(PORTC, UNLOCK_PIN);

			buttonPressed = 1; // Mark button as pressed
			UART_sendString("\nButton Pressed - Start Data Collection\n");
			_delay_ms(500);

			for (counter = ZERO; counter < ARRAY_SIZE; counter++) {
				value = (uint16)ADC_Read(MICROPHONE_PIN);
				buffer[counter] = map16to8(value);
				_delay_ms(1000 / ARRAY_SIZE);
			}

			// Print collected data
			UART_sendString("\nCollected Data: ");
			for (counter = ZERO; counter < ARRAY_SIZE; counter++) {
				UART_sendInt((uint32)buffer[counter]);
				UART_TxChar(' ');
			}
			UART_sendString("\r\n");

			// Classify the collected fingerprint
			Classification result = classifyFingerprint(buffer);

			if (result == LOCK) {
				UART_sendString("Input matches LOCK fingerprint.\n");
				SET_BIT(PORTD, LOCK_PIN);
			}
			else if (result == UNLOCK) {
				UART_sendString("Input matches UNLOCK fingerprint.\n");
				SET_BIT(PORTC, UNLOCK_PIN);
			}
			else {
				UART_sendString("Input classification UNKNOWN.\n");
			}
			
			// Add a small delay to prevent rapid re-detection of button press
			_delay_ms(100);
		}
		else if (BIT_IS_SET(PIND, BUTTON_PIN)) {
			buttonPressed = 0; // Reset button press state if button is released
			_delay_ms(100); // Delay to debounce the button
		}
	}
	
	return 0;
}


